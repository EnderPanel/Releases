# EnderPanel Windows Installer
# Run with: irm https://enderpanel.space/install.ps1 | iex

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Success([string]$Message) {
    Write-Host "[OK] $Message" -ForegroundColor Green
}

Write-Host "=====================================" -ForegroundColor Magenta
Write-Host "       EnderPanel Installer          " -ForegroundColor Magenta
Write-Host "              Windows                " -ForegroundColor Magenta
Write-Host "=====================================" -ForegroundColor Magenta

# Enable scripting if needed
try { Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force } catch {}

# Check admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Please run PowerShell as Administrator and try again." -ForegroundColor Red
    Write-Host "Right-click PowerShell -> Run as Administrator" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:USERPROFILE "EnderPanel"
$ReleaseVersion = "__RELEASE_VERSION__"
$ReleaseUrl = "https://raw.githubusercontent.com/EnderPanel/Releases/main/enderpanel-latest.tar.gz"

function Refresh-Path {
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
}

function Resolve-CommandPath {
    param(
        [Parameter(Mandatory = $true)][string[]]$Candidates
    )

    foreach ($Candidate in $Candidates) {
        $Command = Get-Command $Candidate -ErrorAction SilentlyContinue
        if ($Command -and $Command.Source) {
            return $Command.Source
        }
    }

    return $null
}

function Wait-ForDockerDaemon {
    param(
        [int]$TimeoutSeconds = 180
    )

    $DockerCmd = Resolve-CommandPath @("docker.exe", "docker")
    if (-not $DockerCmd) {
        throw "Docker CLI was not found."
    }

    $Deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $Deadline) {
        & $DockerCmd info *>$null
        if ($LASTEXITCODE -eq 0) {
            return
        }
        Start-Sleep -Seconds 3
    }

    throw "Docker Desktop is installed, but the Docker daemon did not become ready within ${TimeoutSeconds} seconds."
}

function Install-DownloadedExe {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$FileName,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    $DownloadPath = Join-Path $env:TEMP $FileName
    Invoke-WebRequest -Uri $Url -OutFile $DownloadPath
    try {
        $Signature = Get-AuthenticodeSignature -LiteralPath $DownloadPath
        if ($Signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid) {
            throw "Downloaded installer has no valid Authenticode signature: $FileName"
        }
        $Process = Start-Process -FilePath $DownloadPath -ArgumentList $Arguments -Wait -PassThru
        if ($Process.ExitCode -ne 0) {
            throw "Installer exited with code $($Process.ExitCode)"
        }
    } finally {
        Remove-Item $DownloadPath -Force -ErrorAction SilentlyContinue
    }
}

function Install-DownloadedMsi {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$FileName,
        [string[]]$ExtraArguments = @()
    )

    $DownloadPath = Join-Path $env:TEMP $FileName
    Invoke-WebRequest -Uri $Url -OutFile $DownloadPath
    try {
        $Signature = Get-AuthenticodeSignature -LiteralPath $DownloadPath
        if ($Signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid) {
            throw "Downloaded installer has no valid Authenticode signature: $FileName"
        }
        $Arguments = @("/i", "`"$DownloadPath`"", "/qn", "/norestart") + $ExtraArguments
        $Process = Start-Process -FilePath "msiexec.exe" -ArgumentList $Arguments -Wait -PassThru
        if ($Process.ExitCode -ne 0) {
            throw "Installer exited with code $($Process.ExitCode)"
        }
    } finally {
        Remove-Item $DownloadPath -Force -ErrorAction SilentlyContinue
    }
}

# Install Python
Write-Host "Checking Python..." -ForegroundColor Cyan
try { python --version *>$null } catch {
    Write-Host "Installing Python 3.12.9..." -ForegroundColor Yellow
    Install-DownloadedExe `
        -Url "https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe" `
        -FileName "python-3.12.9-amd64.exe" `
        -Arguments @("/quiet", "InstallAllUsers=1", "PrependPath=1", "Include_test=0")
    Refresh-Path
}

# Install Node.js
Write-Host "Checking Node.js..." -ForegroundColor Cyan
try { node --version *>$null } catch {
    Write-Host "Installing Node.js 20 LTS..." -ForegroundColor Yellow
    Install-DownloadedMsi `
        -Url "https://nodejs.org/dist/v20.19.0/node-v20.19.0-x64.msi" `
        -FileName "node-v20.19.0-x64.msi"
    Refresh-Path
}

# Java is supplied by the version-specific Docker images built below.

# Install Docker Desktop
Write-Host "Checking Docker Desktop..." -ForegroundColor Cyan
try { docker --version *>$null } catch {
    Write-Host "Please install Docker Desktop from https://docker.com" -ForegroundColor Red
    Start-Process "https://www.docker.com/products/docker-desktop/"
    Read-Host "Press Enter after installing Docker Desktop"
}

$DockerDesktopExe = Join-Path $env:ProgramFiles "Docker\Docker\Docker Desktop.exe"
if (Test-Path $DockerDesktopExe) {
    $DockerDesktopProcess = Get-Process -Name "Docker Desktop" -ErrorAction SilentlyContinue
    if (-not $DockerDesktopProcess) {
        Write-Host "Starting Docker Desktop..." -ForegroundColor Yellow
        Start-Process -FilePath $DockerDesktopExe
    }
} else {
    Write-Host "Docker Desktop executable not found in Program Files. If Docker is installed elsewhere, make sure it is running." -ForegroundColor Yellow
}
# Configure Docker Desktop RAM allocation (Windows via WSL2)
Write-Host ""
Write-Host "Configuring Docker Desktop RAM allocation..." -ForegroundColor Cyan

$TotalRAM = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum
$TotalRAM_GB = [math]::Round($TotalRAM / 1GB, 1)
$DefaultAlloc_GB = [math]::Max(2, [math]::Floor($TotalRAM_GB / 2))

Write-Host "Your system has ${TotalRAM_GB}GB of RAM." -ForegroundColor White
$InputRam = Read-Host "How much RAM (GB) should Docker/WSL2 use? [default: ${DefaultAlloc_GB}GB]"
if (-not $InputRam) { $InputRam = $DefaultAlloc_GB }

$DefaultSwap_GB = [math]::Max(2, [math]::Floor([int]$InputRam / 2))
$InputSwap = Read-Host "How much swap (GB) for containers? [default: ${DefaultSwap_GB}GB]"
if (-not $InputSwap) { $InputSwap = $DefaultSwap_GB }

$WslConfig = "$env:USERPROFILE\.wslconfig"
$WslContent = "[wsl2]`nmemory=${InputRam}GB`nswap=${InputSwap}GB`nlocalhostForwarding=true`n"
Set-Content -Path $WslConfig -Value $WslContent -Encoding UTF8

Write-Host "Docker WSL2 RAM: ${InputRam}GB, Swap: ${InputSwap}GB (saved to $WslConfig)." -ForegroundColor Green
Write-Host "Restart WSL2 and Docker Desktop for changes to take effect." -ForegroundColor Yellow
Write-Host "  Run: wsl --shutdown" -ForegroundColor Gray
Write-Host ""

Write-Host "Waiting for Docker Desktop to become ready..." -ForegroundColor Cyan
Wait-ForDockerDaemon


# Check if running from local source (installer is in same dir as backend/)
$LocalSource = $null
$CurrentDir = (Get-Location).Path
if (Test-Path "$CurrentDir\backend\main.py" -and Test-Path "$CurrentDir\backend\requirements.txt") {
    $LocalSource = "$CurrentDir"
}

Write-Host ""
if ($LocalSource) {
    Write-Host "Local EnderPanel source detected. Installing from $LocalSource..." -ForegroundColor Cyan
    $SourcePath = [System.IO.Path]::GetFullPath($LocalSource).TrimEnd('\')
    $DestinationPath = [System.IO.Path]::GetFullPath($InstallDir).TrimEnd('\')

    if ($SourcePath -eq $DestinationPath) {
        Write-Success "Already running from the installation directory; updating in place."
    } elseif (Test-Path $InstallDir) {
        # Preserve existing data on upgrade
        Write-Host "Existing installation found. Upgrading..." -ForegroundColor Yellow
        if (Test-Path "$InstallDir\backend\enderpanel.db") {
            Copy-Item "$InstallDir\backend\enderpanel.db" "$LocalSource\backend\" -Force
        } elseif (Test-Path "$InstallDir\backend\mcpanel.db") {
            Copy-Item "$InstallDir\backend\mcpanel.db" "$LocalSource\backend\enderpanel.db" -Force
        }
        if (Test-Path "$InstallDir\backend\servers") { Copy-Item "$InstallDir\backend\servers" "$LocalSource\backend\" -Recurse -Force }
        if (Test-Path "$InstallDir\backend\avatars") { Copy-Item "$InstallDir\backend\avatars" "$LocalSource\backend\" -Recurse -Force }
        if (Test-Path "$InstallDir\backend\data") { Copy-Item "$InstallDir\backend\data" "$LocalSource\backend\" -Recurse -Force }

        Remove-Item -Recurse -Force $InstallDir
        New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
        Copy-Item "$LocalSource\*" $InstallDir -Recurse -Force
    } else {
        New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
        Copy-Item "$LocalSource\*" $InstallDir -Recurse -Force
    }
} else {
    Write-Host ""
    Write-Host "No local source found. Please run this installer from the EnderPanel source directory." -ForegroundColor Red
    Write-Host "Expected: A 'backend' folder with requirements.txt in the same directory as this script." -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path "$InstallDir\backend")) {
    Write-Host "Backend folder not found. Installation may have failed. Please try again." -ForegroundColor Red
    exit 1
}

# Install dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Cyan
Set-Location "$InstallDir\backend"
pip install -r requirements.txt

Write-Host "Installing Node dependencies..." -ForegroundColor Cyan
Set-Location "$InstallDir\frontend"
$NpmCmd = Resolve-CommandPath @("npm.cmd", "npm")
if (-not $NpmCmd) {
    throw "npm was not found after installation."
}
& $NpmCmd ci
if ($LASTEXITCODE -ne 0) {
    throw "npm ci failed with exit code $LASTEXITCODE"
}

# Build frontend
Write-Host "Building frontend..." -ForegroundColor Cyan
$NpxCmd = Resolve-CommandPath @("npx.cmd", "npx")
if (-not $NpxCmd) {
    throw "npx was not found after Node.js installation."
}
& $NpxCmd vite build
if ($LASTEXITCODE -ne 0) {
    throw "npx vite build failed with exit code $LASTEXITCODE"
}
if (-not (Test-Path "$InstallDir\frontend\dist\index.html")) {
    throw "Frontend build did not create frontend\dist\index.html"
}

# Build Docker images
Write-Step "Building Java runtime images in Docker"
Set-Location "$InstallDir\backend"
$DockerCmd = Resolve-CommandPath @("docker.exe", "docker")
if (-not $DockerCmd) {
    throw "docker command was not found before image build."
}
foreach ($Image in @(
    @{ Tag = "latest"; Dockerfile = "Dockerfile" },
    @{ Tag = "java8"; Dockerfile = "Dockerfile.java8" },
    @{ Tag = "java11"; Dockerfile = "Dockerfile.java11" },
    @{ Tag = "java17"; Dockerfile = "Dockerfile.java17" },
    @{ Tag = "java25"; Dockerfile = "Dockerfile.java25" }
)) {
    & $DockerCmd build -t "mc-panel-server:$($Image.Tag)" -f $Image.Dockerfile .
    if ($LASTEXITCODE -ne 0) {
        throw "Docker image mc-panel-server:$($Image.Tag) failed to build."
    }
}
Write-Success "Java 8, 11, 17, 21, and 25 runtime images are ready."

Write-Host ""
Write-Host "=== Installation Complete ===" -ForegroundColor Green
Write-Host ""
Write-Host "To start EnderPanel:" -ForegroundColor White
Write-Host "  cd '$InstallDir\backend'" -ForegroundColor Gray
Write-Host "  python main.py" -ForegroundColor Gray
Write-Host ""
Write-Host "Then open http://localhost:8000" -ForegroundColor White
Write-Host ""

$start = Read-Host "Start EnderPanel now? (y/n)"
if ($start -eq "y") {
    Set-Location "$InstallDir\backend"
    $env:ENDERPANEL_DISABLE_FRONTEND_DEV = "1"
    python main.py
}
